import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-booking',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, HttpClientModule],
  templateUrl: './booking.component.html',
  styleUrls: ['./booking.component.css']
})
export class BookingComponent implements OnInit {
  bookingForm!: FormGroup;
  error = '';
  minDateTime: string = '';

  constructor(
    private fb: FormBuilder,
    private http: HttpClient,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.bookingForm = this.fb.group({
      userId: ['', Validators.required],
      vehicleType: ['', Validators.required],
      licensePlate: ['', Validators.required],
      start: ['', Validators.required],
      end: ['', Validators.required]
    });

    this.minDateTime = new Date().toISOString().slice(0, 16);
  }

  onSubmit(): void {
    if (this.bookingForm.invalid) {
      this.error = 'Please fill all required fields.';
      return;
    }

    const request = this.bookingForm.value;

    this.http.post('http://localhost:8080/booking/book', request).subscribe({
      next: () => {
        this.error = '';
        this.bookingForm.reset();

        // ✅ Redirect immediately after success
        this.router.navigate(['/dashboard']);
      },
      error: (err) => {
        this.error = err?.error?.message || 'Booking failed.';
        console.error('Booking error:', err);
      }
    });
  }
}
